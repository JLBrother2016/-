#include "lib.h"

int main() {
    foobar(1);
    return 0;
}
