#include "lib.h"
#include <stdio.h>

int main() {
    foobar(2);
    return 0;
}
