/*
 * gcc -static section_mapping.c -o section_maping.elf
 */

#include <stdlib.h>

int main() {
    while (1) {
        sleep(1000);
    }

    return 0;
}
