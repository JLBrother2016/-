extern int shared;

int main()
{
    int a = 0;
    swap(&a, &shared);
}
